//
//  YoutubeKeyGetter.swift
//  IOSMovieProj
//
//  Created by Ahmed Awad on 3/13/20.
//  Copyright © 2020 Ahmed Awad. All rights reserved.
//

import Foundation
protocol YoutubeKeyProtocol{
    func getKey(singleMovieList : [SingleMovie])
}
