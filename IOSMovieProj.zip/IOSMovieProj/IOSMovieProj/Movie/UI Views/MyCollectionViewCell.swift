//
//  MyCollectionViewCell.swift
//  IOSMovieProj
//
//  Created by Ahmed Awad on 3/12/20.
//  Copyright © 2020 Ahmed Awad. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var title: UILabel!
}
